
#ifndef DUMPBENCH_H
#define DUMPBENCH_H

int dumpbench(FILE *);

#endif // DUMPBENCH_H

